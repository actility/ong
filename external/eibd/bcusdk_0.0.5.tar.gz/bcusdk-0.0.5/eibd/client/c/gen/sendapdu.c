#include "c/eibclient-int.h"
#include "def/sendapdu.inc"
