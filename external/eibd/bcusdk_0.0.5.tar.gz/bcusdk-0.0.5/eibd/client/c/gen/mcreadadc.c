#include "c/eibclient-int.h"
#include "def/mcreadadc.inc"
