#include "c/eibclient-int.h"
#include "def/sendtpdu.inc"
