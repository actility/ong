#define MODE  SI
#include "eewrite.c"
