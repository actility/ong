#define MODE  AI
#include "eewrite.c"
