#define MODE  EI
#include "eewrite.c"
