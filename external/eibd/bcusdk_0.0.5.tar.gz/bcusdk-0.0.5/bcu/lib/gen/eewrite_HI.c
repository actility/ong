#define MODE  HI
#include "eewrite.c"
