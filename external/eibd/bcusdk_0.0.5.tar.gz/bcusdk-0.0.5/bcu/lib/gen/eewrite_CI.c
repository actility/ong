#define MODE  CI
#include "eewrite.c"
