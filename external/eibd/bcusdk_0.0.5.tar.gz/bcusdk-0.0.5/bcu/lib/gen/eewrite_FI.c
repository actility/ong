#define MODE  FI
#include "eewrite.c"
