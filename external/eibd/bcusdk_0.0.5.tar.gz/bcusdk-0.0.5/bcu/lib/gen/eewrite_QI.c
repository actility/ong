#define MODE  QI
#include "eewrite.c"
