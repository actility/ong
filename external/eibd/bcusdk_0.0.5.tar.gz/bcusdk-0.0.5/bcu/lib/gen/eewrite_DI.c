#define MODE  DI
#include "eewrite.c"
