#
# @(#)README.txt	1.7 06/10/25
# 
# Copyright  2008  Sun Microsystems, Inc. All rights reserved.
# 

- Compile classes in directory A and B.

- Execute them with
cvm com.sun.xlet.XletRunner -name XletA -path A -name XletB -path B
