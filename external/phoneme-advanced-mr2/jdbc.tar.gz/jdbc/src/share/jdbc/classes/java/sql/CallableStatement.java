/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package java.sql;

public interface CallableStatement extends PreparedStatement {
    public Blob getBlob(int i) throws SQLException;

    public boolean getBoolean(int parameterIndex) throws SQLException;

    public byte getByte(int parameterIndex) throws SQLException;

    public byte[] getBytes(int parameterIndex) throws SQLException;

    public Clob getClob(int parameterIndex) throws SQLException;

    public Date getDate(int parameterIndex) throws SQLException;

    public Date getDate(int parameterIndex, java.util.Calendar cal) throws SQLException;

    public double getDouble(int parameterIndex) throws SQLException;

    public float getFloat(int parameterIndex) throws SQLException;

    public int getInt(int parameterIndex) throws SQLException;

    public long getLong(int parameterIndex) throws SQLException;

    public java.lang.Object getObject(int parameterIndex) throws SQLException;

    public short getShort(int parameterIndex) throws SQLException;

    public java.lang.String getString(int parameterIndex) throws SQLException;

    public Time getTime(int parameterIndex) throws SQLException;

    public Time getTime(int parameterIndex, java.util.Calendar calendar) throws SQLException;

    public Timestamp getTimestamp(int parameterIndex) throws SQLException;

    public Timestamp getTimestamp(int parameterIndex, java.util.Calendar calendar) throws SQLException;

    public java.net.URL getURL(int parameterIndex) throws SQLException;

    public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException;

    public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException;

    public void registerOutParameter(int parameterIndex, int sqlType, java.lang.String typeName) throws SQLException;

    public boolean wasNull() throws SQLException;

}
