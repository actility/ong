/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package java.sql;

import java.io.InputStream;
import java.io.Reader;
import java.util.Calendar;

public interface ResultSet {
    public static final int CLOSE_CURSORS_AT_COMMIT = 2;
    public static final int CONCUR_READ_ONLY = 1007;
    public static final int CONCUR_UPDATABLE = 1008;
    public static final int FETCH_FORWARD = 1000;
    public static final int FETCH_REVERSE = 1001;
    public static final int FETCH_UNKNOWN = 1002;
    public static final int HOLD_CURSORS_OVER_COMMIT = 1;
    public static final int TYPE_FORWARD_ONLY = 1003;
    public static final int TYPE_SCROLL_INSENSITIVE = 1004;
    public static final int TYPE_SCROLL_SENSITIVE = 1005;

    public boolean absolute(int row) throws SQLException;

    public void afterLast() throws SQLException;

    public void beforeFirst() throws SQLException;

    public void cancelRowUpdates() throws SQLException;

    public void clearWarnings() throws SQLException;

    public void close() throws SQLException;

    public void deleteRow() throws SQLException;

    public int findColumn(String columnName) throws SQLException;

    public boolean first() throws SQLException;

    public java.io.InputStream getAsciiStream(int columnIndex) throws SQLException;

    public java.io.InputStream getAsciiStream(String columnName) throws SQLException;

    public java.io.InputStream getBinaryStream(int columnIndex) throws SQLException;

    public java.io.InputStream getBinaryStream(String columnName) throws SQLException;

    public Blob getBlob(int columnIndex) throws SQLException;

    public Blob getBlob(String colName) throws SQLException;

    public boolean getBoolean(int columnIndex) throws SQLException;

    public boolean getBoolean(String columnName) throws SQLException;

    public byte getByte(int columnIndex) throws SQLException;

    public byte getByte(String columnName) throws SQLException;

    public byte[] getBytes(int columnIndex) throws SQLException;

    public byte[] getBytes(String columnName) throws SQLException;

    public java.io.Reader getCharacterStream(int columnIndex) throws SQLException;

    public java.io.Reader getCharacterStream(String columnName) throws SQLException;

    public Clob getClob(int i) throws SQLException;

    public Clob getClob(String colName) throws SQLException;

    public int getConcurrency() throws SQLException;

    public String getCursorName() throws SQLException;

    public Date getDate(int columnIndex) throws SQLException;

    public Date getDate(int columnIndex, Calendar cal) throws SQLException;

    public Date getDate(String columnName) throws SQLException;

    public Date getDate(String columnName, Calendar cal) throws SQLException;

    public double getDouble(int columnIndex) throws SQLException;

    public double getDouble(String columnName) throws SQLException;

    public int getFetchDirection() throws SQLException;

    public int getFetchSize() throws SQLException;

    public float getFloat(int columnIndex) throws SQLException;

    public float getFloat(String columnName) throws SQLException;

    public int getInt(int columnIndex) throws SQLException;

    public int getInt(String columnName) throws SQLException;

    public long getLong(int columnIndex) throws SQLException;

    public long getLong(String columnName) throws SQLException;

    public ResultSetMetaData getMetaData() throws SQLException;

    public Object getObject(int columnIndex) throws SQLException;

    public Object getObject(String columnName) throws SQLException;

    public int getRow() throws SQLException;

    public short getShort(int columnIndex) throws SQLException;

    public short getShort(String columnName) throws SQLException;

    public Statement getStatement() throws SQLException;

    public String getString(int columnIndex) throws SQLException;

    public String getString(String columnName) throws SQLException;

    public Time getTime(int columnIndex) throws SQLException;

    public Time getTime(int columnIndex, Calendar cal) throws SQLException;

    public Time getTime(String columnName) throws SQLException;

    public Time getTime(String columnName, Calendar cal) throws SQLException;

    public Timestamp getTimestamp(int columnIndex) throws SQLException;

    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException;

    public Timestamp getTimestamp(String columnName) throws SQLException;

    public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException;

    public int getType() throws SQLException;

    public java.net.URL getURL(int columnIndex) throws SQLException;

    public java.net.URL getURL(String columnName) throws SQLException;

    public SQLWarning getWarnings() throws SQLException;

    public void insertRow() throws SQLException;

    public boolean isAfterLast() throws SQLException;

    public boolean isBeforeFirst() throws SQLException;

    public boolean isFirst() throws SQLException;

    public boolean isLast() throws SQLException;

    public boolean last() throws SQLException;

    public void moveToCurrentRow() throws SQLException;

    public void moveToInsertRow() throws SQLException;

    public boolean next() throws SQLException;

    public boolean previous() throws SQLException;

    public void refreshRow() throws SQLException;

    public boolean relative(int rows) throws SQLException;

    public boolean rowDeleted() throws SQLException;

    public boolean rowInserted() throws SQLException;

    public boolean rowUpdated() throws SQLException;

    public void setFetchDirection(int direction) throws SQLException;

    public void setFetchSize(int rows) throws SQLException;

    public void updateAsciiStream(int columnIndex, InputStream inputStream, int length) throws SQLException;

    public void updateAsciiStream(String columnName, InputStream inputStream, int length) throws SQLException;

    public void updateBinaryStream(int columnIndex, InputStream inputStream, int length) throws SQLException;

    public void updateBinaryStream(String columnName, InputStream inputStream, int length) throws SQLException;

    public void updateBlob(int columnIndex, Blob blob) throws SQLException;

    public void updateBlob(String columnName, Blob blob) throws SQLException;

    public void updateBoolean(int columnIndex, boolean bool) throws SQLException;

    public void updateBoolean(String columnName, boolean bool) throws SQLException;

    public void updateByte(int columnIndex, byte value) throws SQLException;

    public void updateByte(String columnName, byte value) throws SQLException;

    public void updateBytes(int columnIndex, byte[] tab) throws SQLException;

    public void updateBytes(String columnName, byte[] tab) throws SQLException;

    public void updateCharacterStream(int columnIndex, Reader reader, int length) throws SQLException;

    public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException;

    public void updateClob(int columnIndex, Clob clob) throws SQLException;

    public void updateClob(String columnName, Clob clob) throws SQLException;

    public void updateDate(int columnIndex, Date date) throws SQLException;

    public void updateDate(String columnName, Date date) throws SQLException;

    public void updateDouble(int columnIndex, double value) throws SQLException;

    public void updateDouble(String columnName, double value) throws SQLException;

    public void updateFloat(int columnIndex, float value) throws SQLException;

    public void updateFloat(String columnName, float value) throws SQLException;

    public void updateInt(int columnIndex, int value) throws SQLException;

    public void updateInt(String columnName, int value) throws SQLException;

    public void updateLong(int columnIndex, long value) throws SQLException;

    public void updateLong(String columnName, long value) throws SQLException;

    public void updateNull(int columnIndex) throws SQLException;

    public void updateNull(String columnName) throws SQLException;

    public void updateObject(int columnIndex, Object object) throws SQLException;

    public void updateObject(int columnIndex, Object object, int scale) throws SQLException;

    public void updateObject(String columnName, Object object) throws SQLException;

    public void updateObject(String columnName, Object object, int scale) throws SQLException;

    public void updateRow() throws SQLException;

    public void updateShort(int columnIndex, short value) throws SQLException;

    public void updateShort(String columnName, short value) throws SQLException;

    public void updateString(int columnIndex, String string) throws SQLException;

    public void updateString(String columnName, String string) throws SQLException;

    public void updateTime(int columnIndex, Time time) throws SQLException;

    public void updateTime(String columnName, Time time) throws SQLException;

    public void updateTimestamp(int columnIndex, Timestamp timestamp) throws SQLException;

    public void updateTimestamp(String columnName, Timestamp timestamp) throws SQLException;

    public boolean wasNull() throws SQLException;

}
