/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package javax.sql;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

public interface RowSet extends ResultSet {
    public void addRowSetListener(RowSetListener listener);

    public void clearParameters();

    public void execute();

    public String getCommand();

    public String getDataSourceName();

    public boolean getEscapeProcessing();

    public int getMaxFieldSize();

    public int getMaxRows();

    public String getPassword();

    public int getQueryTimeout();

    public int getTransactionIsolation();

    public java.util.Map getTypeMap();

    public String getUsername();

    public boolean isReadOnly();

    public void removeRowSetListener(RowSetListener listener);

    public void setAsciiStream(int parameterIndex, InputStream inputStream, int length);

    public void setBinaryStream(int parameterIndex, InputStream inputStream, int length);

    public void setBlob(int i, Blob blob);

    public void setBoolean(int parameterIndex, boolean value);

    public void setByte(int parameterIndex, byte value);

    public void setBytes(int parameterIndex, byte[] value);

    public void setCharacterStream(int parameterIndex, java.io.Reader reader, int length);

    public void setClob(int i, Clob clob);

    public void setCommand(String cmd);

    public void setConcurrency(int concurrency);

    public void setDataSourceName(String name);

    public void setDate(int parameterIndex, Date date);

    public void setDate(int parameterIndex, Date date, Calendar calendar);

    public void setDouble(int parameterIndex, double value);

    public void setEscapeProcessing(boolean enable);

    public void setFloat(int parameterIndex, float value);

    public void setInt(int parameterIndex, int value);

    public void setLong(int parameterIndex, long value);

    public void setMaxFieldSize(int max);

    public void setMaxRows(int max);

    public void setNull(int parameterIndex, int sqlType);

    public void setNull(int paramIndex, int sqlType, String typeName);

    public void setObject(int parameterIndex, Object object);

    public void setObject(int parameterIndex, Object object, int targetSqlType);

    public void setObject(int parameterIndex, Object object, int targetSqlType, int scale);

    public void setPassword(String password);

    public void setQueryTimeout(int seconds);

    public void setReadOnly(boolean value);

    public void setShort(int parameterIndex, short value);

    public void setString(int parameterIndex, String string);

    public void setTime(int parameterIndex, Time time);

    public void setTime(int parameterIndex, Time time, Calendar calendar);

    public void setTimestamp(int parameterIndex, Timestamp time);

    public void setTimestamp(int parameterIndex, Timestamp time, Calendar calendar);

    public void setTransactionIsolation(int level);

    public void setType(int type);

    public void setTypeMap(java.util.Map map);

    public void setUsername(String username);

}
