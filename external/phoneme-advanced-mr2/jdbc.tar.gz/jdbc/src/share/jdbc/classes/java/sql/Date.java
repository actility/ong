/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package java.sql;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Date extends java.util.Date {

    /**
     * 
     */
    private static final long serialVersionUID = 3123150556026461670L;
    private final static DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

    public Date(long millis) {
        super(millis);
    }

    public java.lang.String toString() {
        Calendar cal = new GregorianCalendar();
        cal.setTime(this);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH) + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);

        StringBuffer sb = new StringBuffer();
        sb.append(year);
        sb.append('-');
        sb.append(month);
        sb.append('-');
        sb.append(day);

        return (sb.toString());
    }

    static Date valueOf(java.lang.String s) {
        try {
            return new Date(df.parse(s).getTime());
        } catch (ParseException e) {
            throw (new IllegalArgumentException("Badly formatted date : " + e.getMessage()));
        }
    }
}
