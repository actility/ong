/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package java.sql;

public class Types {
    public static final int     ARRAY  = 2003;
    public static final int     BIGINT  =-5;
    public static final int     BINARY  =-2;
    public static final int     BIT     =-7;
    public static final int     BLOB   = 2004;
    public static final int     BOOLEAN    = 16;
    public static final int     CHAR   = 1;
    public static final int     CLOB   = 2005;
    public static final int     DATALINK   = 70;
    public static final int     DATE   = 91;
    public static final int     DECIMAL    = 3;
    public static final int     DISTINCT   = 2001;
    public static final int     DOUBLE = 8;
    public static final int     FLOAT  = 6;
    public static final int     INTEGER    = 4;
    public static final int     JAVA_OBJECT    = 2000;
    public static final int     LONGVARBINARY   =-4;
    public static final int     LONGVARCHAR     =-1;
    public static final int     NULL   = 0;
    public static final int     NUMERIC    = 2;
    public static final int     OTHER  = 1111;
    public static final int     REAL   = 7;
    public static final int     REF    = 2006;
    public static final int     SMALLINT   = 5;
    public static final int     STRUCT = 2002;
    public static final int     TIME   = 92;
    public static final int     TIMESTAMP  = 93;
    public static final int     TINYINT     =-6;
    public static final int     VARBINARY   =-3;
    public static final int     VARCHAR    = 12;
}
