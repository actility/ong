/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package java.sql;

public interface PreparedStatement extends Statement {

    public void addBatch()throws SQLException;

    public boolean execute()throws SQLException;

    public ResultSet executeQuery()throws SQLException;

    public int executeUpdate()throws SQLException;

    public void setNull(int parameterIndex, int sqlType) throws SQLException;

    public void setBoolean(int parameterIndex, boolean x) throws SQLException;

    public void setByte(int parameterIndex, byte x) throws SQLException;

    public void setShort(int parameterIndex, short x) throws SQLException;

    public void setInt(int parameterIndex, int x) throws SQLException;

    public void setLong(int parameterIndex, long x) throws SQLException;

    public void setFloat(int parameterIndex, float x) throws SQLException;

    public void setDouble(int parameterIndex, double x) throws SQLException;

    public void setString(int parameterIndex, java.lang.String x) throws SQLException;

    public void setBytes(int parameterIndex, byte[] x) throws SQLException;

    public void setDate(int parameterIndex, Date x) throws SQLException;

    public void setTime(int parameterIndex, Time x) throws SQLException;

    public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException;

    public void setAsciiStream(int parameterIndex, java.io.InputStream x, int length) throws SQLException;

    public void setBinaryStream(int parameterIndex, java.io.InputStream x, int length) throws SQLException;

    public void clearParameters() throws SQLException;

    public void setObject(int parameterIndex, java.lang.Object x, int targetSqlType, int scale) throws SQLException;

    public void setObject(int parameterIndex, java.lang.Object x, int targetSqlType) throws SQLException;

    public void setObject(int parameterIndex, java.lang.Object x) throws SQLException;

    public void setCharacterStream(int parameterIndex, java.io.Reader reader, int length) throws SQLException;

    public void setBlob(int i, Blob x) throws SQLException;

    public void setClob(int i, Clob x) throws SQLException;

    public ResultSetMetaData getMetaData() throws SQLException;

    public void setDate(int parameterIndex, Date x, java.util.Calendar cal) throws SQLException;

    public void setTime(int parameterIndex, Time x, java.util.Calendar cal) throws SQLException;

    public void setTimestamp(int parameterIndex, Timestamp x, java.util.Calendar cal) throws SQLException;

    public void setNull(int paramIndex, int sqlType, java.lang.String typeName) throws SQLException;

    public void setURL(int parameterIndex, java.net.URL x) throws SQLException;

}
