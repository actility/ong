/*
 * Copyright   Actility, SA. All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License version
 * 2 only, as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License version 2 for more details (a copy is
 * included at /legal/license.txt).
 * 
 * You should have received a copy of the GNU General Public License
 * version 2 along with this work; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 * 
 * Please contact Actility, SA.,  4, rue Amp�re 22300 LANNION FRANCE
 * or visit www.actility.com if you need additional
 * information or have any questions.
 * 
 * id $Id:  $
 * author $Author:  $
 * version $Revision: $
 * lastrevision $Date:  $
 * modifiedby $LastChangedBy:  $
 * lastmodified $LastChangedDate:  $
 */

package java.sql;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Timestamp extends java.util.Date {

    /**
     * 
     */
    private static final long serialVersionUID = 5952318001583382510L;
    private int nanos;
    
    public Timestamp(long time) {
        super((time/1000)*1000);
        this.nanos = (int) ((time - super.getTime())*1000000);
    }

    public boolean after(Timestamp ts) {
        boolean valret;
         long time1 = getTime();
         long time2 = ts.getTime();
         if (time1 > time2 || (time1 == time2 && getNanos() > ts.getNanos())){
             valret =  true;
         }else{
             valret = false;
         }
         return(valret);
    }

    public boolean before(Timestamp ts) {
        boolean valret;
        long time1 = getTime();
        long time2 = ts.getTime();
        if (time1 < time2 || (time1 == time2 && getNanos() < ts.getNanos())){
            valret =  true;
        }else{
            valret = false;
        }
        return(valret);

    }

    public int compareTo(java.lang.Object o) {
        return compareTo((Timestamp) o);
    }

    public int compareTo(Timestamp ts) {
        int valret;
        int s = super.compareTo((java.util.Date) ts);
        if (s != 0) {
            valret = s;
        } else {
            // If Date components were equal, then we check the nanoseconds.
            valret = nanos - ts.nanos;
        }
        return (valret);
    }

    public boolean equals(java.lang.Object o) {
        boolean valret;
        if(o instanceof Timestamp){
            valret = this.equals(o);
        }else{
            valret = false;
        }
        return(valret);
    }

    public boolean equals(Timestamp ts) {
        return(ts != null && this.getTime()==ts.getTime() && this.getNanos()==ts.getNanos());
    }

    public int getNanos() {
        return(nanos);
    }

    public long getTime() {
        return super.getTime() + (nanos / 1000000);
    }

    public void setNanos(int n) {
        if (n > 999999999 || n < 0) {
            throw new IllegalArgumentException("nanos value must be betweeb 0 and 1 billion");
        }
        this.nanos = n;
    }

    public void setTime(long time) {
        super.setTime(time);
    }

    public java.lang.String toString() {
        DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        StringBuffer sb = new StringBuffer();
        dateFormat.format(this, sb, null);
        
        sb.append('.');
        
        DecimalFormat decFormat = new DecimalFormat("000000000");
        decFormat.format(nanos, sb, null);
        
        return(sb.toString());
    }

    public static Timestamp valueOf(java.lang.String s) {
        Timestamp valret;
        
        int dotIndex = s.indexOf(".");
        String entire;
        String fractional;
        if(dotIndex==-1){
            entire = s;
            fractional = null;
        }else{
            entire = s.substring(0, dotIndex);
            fractional = s.substring(dotIndex)+1;
        }
        
        DateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date d;
        try {
            d = dateFormat.parse(entire);
        } catch (ParseException e) {
            throw(new IllegalArgumentException("Timestamp "+s+" has incorrect format  "));
        }
        valret = new Timestamp(d.getTime());
        
        if(fractional != null && fractional.length()>0){
            valret.setNanos(  Integer.parseInt(fractional));
        }
        return(valret);
    }

}
